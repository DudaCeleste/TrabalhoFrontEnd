
package Source;

public class Cliente {
    private static int proximoIdentificador = 1;
    private int identificador;
    private String tipo, nome, documento;
    private float saldo;

    
    // construtor
    public Cliente(String tipo, String nome, String documento) {
        this.identificador = proximoIdentificador++;
        this.tipo = tipo;
        this.nome = nome;
        this.documento = documento;
        this.saldo = 0.0f; 
    }

    
    // getters e setters
        
    public int getIdentificador() {
        return identificador;
    }

    public String getTipo() {
        return tipo;
    }

    public String getNome() {
        return nome;
    }

    public String getDocumento() {
        return documento;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    
  // saque e deposito
    public boolean sacar(float valor) {
        if (valor > 0 && valor <= saldo) {
            saldo -= valor;
            return true; 
        }
        return false; 
    }

    public boolean depositar(float valor) {
        if (valor > 0) {
            saldo += valor;
            return true; 
        }
        return false; 
    }

    
    // transferencia
    public boolean transferir(float valor, Cliente recebidor) {
        if (valor > 0 && saldo >= valor) {
            saldo -= valor;
            recebidor.depositar(valor);
            return true;
        }
        return false; 
    }
}
