
package Source;
import java.util.ArrayList;

public class Banco {
    private ArrayList<Cliente> clientes;

    // Construtor
    public Banco() {
        this.clientes = new ArrayList<>();
    }

    // adicionar cliente
    public void addCliente(Cliente c) {
        clientes.add(c);
    }

    // remover cliente
    public boolean removeCliente(Cliente c) {
        return clientes.remove(c);
    }

    // saldo total do banco
    public float getSaldoTotal() {
        float saldoTotal = 0;
        for (Cliente c : clientes) {
            saldoTotal += c.getSaldo();
        }
        return saldoTotal;
        
    }
    
     public void imprimirClientes() {
        System.out.println("Clientes:\n");
        for (Cliente c : clientes) { 
            System.out.println("Id cliente: " + c.getIdentificador());
            System.out.println("Tipo: " + c.getTipo());
            System.out.println("Nome: " + c.getNome());
            System.out.println("Documento: " + c.getDocumento());
            System.out.println("Saldo: " + c.getSaldo());
            System.out.println();
        }
}
}
